from django.urls import path
from .views import register_disaster, announcement

urlpatterns = [
    path('register/', register_disaster, name='register_disaster'),
    path('announcements/', announcement, name='announcement'),
]
