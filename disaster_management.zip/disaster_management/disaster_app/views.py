from django.shortcuts import render, redirect
from .models import DisasterReport
from .forms import DisasterReportForm

def register_disaster(request):
    if request.method == "POST":
        form = DisasterReportForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('announcement') 
    else:
        form = DisasterReportForm()
        
        

    return render(request, "disaster_register.html", {"form": form})

def announcement(request):
    reports = DisasterReport.objects.all().order_by('-created_at')  # Show latest first
    return render(request, "announcement.html", {"reports": reports})
