from django.contrib import admin
from .models import DisasterReport

@admin.register(DisasterReport)
class DisasterReportAdmin(admin.ModelAdmin):
    list_display = ('name', 'location', 'created_at')  # Display fields in admin panel
    search_fields = ('name', 'location')  # Enable search
    list_filter = ('created_at',)  # Filter by date

